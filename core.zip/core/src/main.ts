import express from 'express';
import loginRoutes from "./routes/loginRoute";
import * as dotenv from 'dotenv'
import connectDB from './config/db';
import { WhiteList } from './entity/whitelistEntity';
// import whitelistRoutes from './routes/whitelistRoutes';

const app = express();
dotenv.config()

const port = process.env.PORT;
const mongoDBURL = process.env.MONGOURI;
console.log(process.env.MONGOURI)

connectDB(mongoDBURL).then((res) =>{
    console.log(res);
})

app.use(express.static(__dirname+'./public/'))
app.use(express.json());
app.use(express.urlencoded({extended:false}))

app.use('/api',loginRoutes);
// app.use('/api',whitelistRoutes);

app.listen(port , () => {
    console.log(`server started on ${port}`)
})