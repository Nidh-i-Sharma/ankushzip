import { NextFunction } from "connect";
import express, { Request, Response } from "express";
import { Any } from "typeorm";
import { User } from "../entity/userEntity";
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
import myDataSource from "../config/db";
import multer from 'multer'
import path from 'path'

// const upload = multer()

dotenv.config();
const secret: string = (process.env.JWTSECRET_KEY) ? process.env.JWTSECRET_KEY : "";


export async function authenticateToken(req: any, res: Response, next: NextFunction) {
    try {
        const authHeader = req.headers['authorization'] as string | undefined;
        const token = authHeader && authHeader.split(' ')[1]
        if (token == null) return res.sendStatus(401)
    
        jwt.verify(token, secret, (err: any, user: any) => {
            console.log(err)
            if (err) return res.sendStatus(403).send("A token is required for authentication");
            req.send = user
            next()
        })
    } catch(error) {
        res.send("Internal Server Error");
    }
}

export function generateAccessToken(user: any) {
    return jwt.sign({ email: user.email, isSuperAdmin: user.isSuperAdmin }, secret, { expiresIn: '10m' })
}

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, './public/uploads/')
    },
    filename: (req, file, cb) => {
        //   const fileName = Date.now() + '-' + '.jpg')
        console.log(file);
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

export const upload = multer({
    storage: storage, 
    fileFilter: (req, file, callback) => {
        var ext = path.extname(file.originalname);
        if (ext !== '.png' && ext !== '.jpg' && ext !== '.gif' && ext !== '.jpeg') {
            return callback(new Error('Only images are allowed'))
        }
        callback(null, true)
    }
}).single('image_upload');
