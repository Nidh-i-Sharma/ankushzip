import mongoose from 'mongoose';

// create an schema
const artistSchema = new mongoose.Schema({
    artistName:{
        type :String,
        required : true
    },
    artistImage:{
        type :String,
        required : true 
    },
    artistDescription:{
        type :String,
        required : true 
    }
})

const artistModal = mongoose.model('artist' , artistSchema)
export default artistModal


// username: String, fullname, contact number , role =0, created date and updated , status :block active inactive
