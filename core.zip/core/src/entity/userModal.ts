import mongoose from 'mongoose';

// create an schema
const userSchema = new mongoose.Schema({
    fullname:{
        type :String,
        required : true
    },
    email:{
        type :String,
        required : true 
    },
    password:{
        type :String,
        required : true 
    },
    contactNumber:{
        type :String,
    },
    role:{
        type :String,
    },
    createdAt:{
        type: Date, 
        default: Date.now
    },
    status:{
        type :String
    }
})

const userModal = mongoose.model('user' , userSchema)
export default userModal


// username: String, fullname, contact number , role =0, created date and updated , status :block active inactive
