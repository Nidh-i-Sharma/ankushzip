import { Entity, Column, PrimaryGeneratedColumn , BaseEntity, CreateDateColumn, UpdateDateColumn, BeforeInsert, BeforeUpdate, JoinColumn, Index } from "typeorm"
@Entity({ name: 'whitelist' })
export class WhiteList extends BaseEntity{
    @PrimaryGeneratedColumn()
    id: number
    
    @Index({ fulltext: true })
    @Column("varchar")
    imageName: string;

    @Column()
    image: string

    @Index({ fulltext: true })
    @Column({
        nullable: false
    })
    artistName: string

    @Column()
    price: number

    @Column()
    description:string

    @Column()
    originalSize:number

    @Column()
    year:number

    @Column()
    medium:string

    @Column()
    signature:number

    @Column()
    authencity:string

    @Column()
    provenence:string

    @Column({ 
        type: 'timestamp', 
        precision: 3,
        nullable: true
      })
      createdAt: Date;
    
      @Column({
        type: 'timestamp', 
        precision: 3,
        nullable: true
      })
      updatedAt: Date;
    

}