// import express from "express";
// import multer from "multer";
// import {postWhiteList, getWhiteListById, filterWhiteList,  updateWhiteList, filterByDate, filterByPrice} from "../controllers/whitelistController";
// import { authenticateToken, upload} from "../middleware/authapi";

// var router = express.Router();

// router.get('/whitelist/:id',authenticateToken, getWhiteListById)
// router.post('/whitelist/search', authenticateToken,filterWhiteList)
// router.post('/whitelist/datefilter', authenticateToken,filterByDate)
// router.post('/whitelist/pricefilter',authenticateToken, filterByPrice)
// router.post('/whitelist', upload, postWhiteList)
// router.post('/updatewhitelist/:id',  authenticateToken,updateWhiteList)

// export default router; 