import express from "express";
import {changePassword, createUser, deleteUser, loginUser} from "../controllers/loginController";
import { authenticateToken} from "../middleware/authapi";

var router = express.Router();

router.post('/login', loginUser)
router.post('/signup',authenticateToken, createUser)


// router.get('/forgetpassword/:userId/:token',sendforgetpasswordLink)

// router.post('/forgetpassword',forgetpassword)

// router.get('/resetpassword/:userId/:token',authenticateToken,resetPasswordPost)

// router.get('/resetpasswprd/:userId/:token',authenticateToken,resetPasswordPost)


router.post('/updatepassword',authenticateToken,changePassword)
router.delete('/deleteadmin', authenticateToken, deleteUser)

export default router;