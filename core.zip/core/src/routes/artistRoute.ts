import express from "express";
import { createNewArtist, deleteArtist, getAllArtist, getArtistById, updateArtist, updateArtistImage } from "../controllers/artistController";
import artistModal from "../entity/artistModal";
import { authenticateToken, upload} from "../middleware/authapi";

var router = express.Router();

router.post('/createartist', authenticateToken,createNewArtist)
router.post('/updateartistImage',[authenticateToken,upload] ,updateArtistImage)
router.get('/getartist', authenticateToken, getAllArtist)
router.get('/getartist', authenticateToken, getArtistById)
router.get('/deleteartist', authenticateToken, deleteArtist)
router.get('/updateartist', authenticateToken, updateArtist)


export default router;