// import express, { query, Request, Response } from "express";
// import moment from 'moment';
// import { WhiteList } from "../entity/whitelistEntity";
// import myDataSource from "../config/db";
// import jwt from 'jsonwebtoken'
// import { generateAccessToken } from "../middleware/authapi";
// import { Like, Between, Equal } from "typeorm";


// export async function getWhiteListById(req: any, res: Response) {
//     try {
//         let id = parseInt(req.params.id);
//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         const result = await whitelistRepository.findOneBy({
//             id: id
//         });
//         res.send({ message: "Data fetch successfully", data: { result } })
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function postWhiteList(req: any, res: Response) {
//     try {
//         let {
//             imageName,
//             price,
//             createdAt,
//             authencity, artistName, description, originalSize, medium, year, provenence, signature, updatedAt } = req.body;

//             console.log(req.file);
    
//             if (req.file == undefined) {
//               return res.send(`You must select a Image.`);
//             }
//             let fileName = req.file.filename
//             let imageSrc = 'http://127.0.0.1:3000/images/' + req.file.filename
//             console.log(fileName);

//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         let now = moment().format('LLLL');
//         let momentDate = moment(createdAt).format("YYYY-MM-DD HH:mm:ss");
//         const result = await whitelistRepository.save({
//             image: imageSrc,
//             imageName: imageName,
//             price: price,
//             createdAt: momentDate,
//             authencity: authencity, 
//             artistName: artistName, description: description, originalSize: originalSize, medium: medium, year: year, provenence: provenence, signature: signature, updatedAt: updatedAt
//         });
//         res.status(201).json({ message: "WhiteList saves successfully", data: { result } })

//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function filterWhiteList(req: any, res: Response) {
//     try {
//         let { toDate, fromDate } = req.body;

//         toDate = moment(toDate).format("YYYY-MM-DD HH:mm:ss");
//         fromDate = moment(fromDate).format("YYYY-MM-DD HH:mm:ss");

//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         const builder = whitelistRepository.createQueryBuilder('whitelist')

//         if (req.body.imageName) {
//             let searchKey = req.body.imageName;
//             let result = await whitelistRepository.find({ where: { imageName: Like(`${searchKey}%`) } });
//             console.log(result);
//             res.send({ message: "Data fetch successfully", data: { result } })
//         }
//         if (req.body?.artistName) {
//             let searchKey = req.body.artistName;
//             let result = await whitelistRepository.find({ where: { artistName: Like(`${searchKey}%`) } });
//             console.log(result);
//             res.send({ message: "Data fetch successfully", data: { result } })
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }
// export async function filterByDate(req:any, res:Response) {
//     try{
//         let { toDate, fromDate } = req.body;

//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         if (toDate && fromDate) {
//             //search query for date range 
//             const result = await whitelistRepository.findBy({ createdAt: Between(toDate, fromDate) })
//             res.send({ message: "Data fetch successfully", data: { result } })
//         } else if (toDate || fromDate) {
//             // either seach by todate or fromdate
//             let result = await whitelistRepository.findBy({
//                 createdAt: Equal(toDate),
//             })
//             res.send({ message: "Data fetch successfully", data: { result } })
//         }
//     } catch(error){
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function filterByPrice(req:any, res:Response) {
//     try{
//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         if (req.body?.price) {
//             let price = parseInt(req.body.price);
//             let result = await whitelistRepository.findBy({
//                 price: Equal(price)
//             })
//             res.send({ message: "Price fetch successfully", data: { result } })
//         } else if (req.body?.startPrice && req.body?.endPrice) {
//             let startPrice = parseInt(req.body.startPrice);
//             let endPrice = parseInt(req.body.endPrice);
//             let pricerange =  await whitelistRepository.findBy({ price: Between(startPrice, endPrice) })
//             res.send({ message: "Price Range fetch successfully", data: { pricerange } })
//         }
//     } catch(error){
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function updateWhiteList(req: any, res: Response) {
//     try {
//         let whiteListId = req.params.id;
//         const whitelistRepository = myDataSource.getRepository('whitelist');
//         let  whitelistExisting = await whitelistRepository.findOneBy({ id : whiteListId })

//         if(whitelistExisting && whitelistExisting.createdAt){
//             return res.status(200).jsonp({message:"whitelist can't be update"})
//         }
//         let  imageName  = req.body.imageName;
//         const result = await whitelistRepository.update(whiteListId, {
//             imageName: imageName
//         })
//         res.send('updated data');
//         // const data = await whitelistRepository.upsert({  : "Contraption" });
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }
