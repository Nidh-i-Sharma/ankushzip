import { Request, Response } from "express";
import artistModal from "../entity/artistModal";

export async function createNewArtist(req:Request,res:Response) {
    try {
        let {artistname, profileImage, description} = req.body
        if(!artistname) return res.status(400).json({message:"Please send artistname"})
        let newArtist = new artistModal({
            artistName:artistname,
            artistImage:profileImage,
            artistDescription:description
        })
        let result =await newArtist.save();
        
        
    } catch(error){

    }
}
export async function getAllArtist() {
    
}
export async function getArtistById() {
    
}
export async function deleteArtist() {
    
}
export async function updateArtist() {
    
}
export async function updateArtistImage() {
    
}