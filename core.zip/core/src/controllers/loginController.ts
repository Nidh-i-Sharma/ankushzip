import express, { Request, Response } from "express";
import * as dotenv from 'dotenv'
import userModal from '../entity/userModal'
dotenv.config()
import myDataSource from "../config/db";
import bcrypt, { genSalt } from 'bcrypt'
import jwt from 'jsonwebtoken'
import { generateAccessToken } from "../middleware/authapi";

const app = express();


export async function loginUser(req: Request, res: Response) {
    try {
        const { email, password } = req.body;
        var validPassword;
        const user: any = await userModal.findOne({ email: email });
        // const user = await userModal.findOneBy({
        //     email: email
        // })
        if (user) {
            validPassword = await bcrypt.compare(password, user.password);
        }
        if (!user || !validPassword) {
            return res.json({ message: "Email or password is invalid" })
        }
        const token = generateAccessToken(user)
        res.send({ user, token });

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" })
    }
}

export async function createUser(this: any, req: Request, res: Response) {

    let { fullname, email, password, contactNumber, status, role, createdAt } = req.body;
    try {

        // const checkAdmin = await superAdminValidator(req.query?.email as any);
        // if (!(checkAdmin)) return res.json({ message: "Only SuperAdmin can add new admin!" })

        // const userRepository = myDataSource.getRepository('user');
        const existingUser = await userModal.findOne({ email: req.body.email })

        if (existingUser) {
            return res.json({ message: "This User is already exist!" })
        }
        // const isSuperAdmin = false;

        bcrypt.hash(req.body.password, 10, async (err, encrypted) => {
            const saveUser = new userModal(
                {
                    fullname: fullname, email: email, password: encrypted,
                    contactNumber: contactNumber,
                    createdAt: createdAt,
                    role: role,
                    status: status
                });
            let result = await saveUser.save();
            res.status(201).json({ message: "User Created Successfully" })
        })

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" })
    }
}
// export async function forgetpassword(req: Request, res: Response) {
//     //make sure user exist in db
//     try {
//         const { email } = req.body;

//         const checkAdmin = await superAdminValidator(req.query?.email as any);
//         if (!(checkAdmin)) return res.json({ message: "Only SuperAdmin can do this!" })

//         const user = await User.findOneBy({
//             email: email
//         })
//         if (!user) {
//             return res.json({ message: "User not found" })
//         } else {
//             //user exist , generate otp 
//             const secret = process.env.JWTSECRET_KEY + user.password;
//             const payload = {
//                 email: user.email,
//                 userId: user.userId
//             }
//             const token = jwt.sign(payload, secret, { expiresIn: '15m' });
//             const link = `http://localhost:3000/resetpassword/${user.userId}/${token}`;
//             const data = {
//                 from: "noreply@artfi.world",
//                 to: email,
//                 subject: "Passord Reset Link",
//                 html: `
//                 <h2>Please click on the link to reset your password</h2>
//                 <p>${link}</p>
//                 `
//             }
//             console.log(link);
//             res.send({ message: "Password reset link send successfully", data: data });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function sendforgetpasswordLink(req: Request, res: Response) {
//     //make sure user exist in db
//     try {
//         const { userId, token } = req.params;
//         const { password, confirmPassword } = req.body;

//         //check if this id exist in db
//         const user = await User.findOneBy({
//             userId: parseInt(userId)
//         })
//         if (!user || !confirmPassword) {
//             return res.json({ message: "New Password must be sent with userId" })
//         } else {
//             //user exist , generate otp 
//             const secret = process.env.JWTSECRET_KEY + user.password;
//             try {
//                 const payload = jwt.verify(token, secret)
//                 //update the pass
//                 const userRepository = myDataSource.getRepository('user');

//                 var hashPass = bcrypt.hash(confirmPassword, 10, (err, encrypted) => {
//                     userRepository.update(userId, {
//                         password: encrypted
//                     })
//                 })
//                 //hash the pass
//                 res.send({ message: 'Password updates successfully', email: user.email });
//             } catch (error) {
//                 console.log(error);
//                 res.send(error);
//             }
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

// export async function resetPasswordPost(req: Request, res: Response) {
//     //make sure user exist in db
//     try {
//         const { userId, token } = req.params;
//         //check if this id exist in db
//         const user = await User.findOneBy({
//             userId: parseInt(userId)
//         })
//         if (!user) {
//             return res.json({ message: "Invaild userId" })
//         } else {

//             //user exist , generate otp 
//             const secret = process.env.JWTSECRET_KEY + user.password;
//             try {
//                 const payload = jwt.verify(token, secret)
//                 res.send({ message: 'reset password', email: user.email });
//             } catch (error) {
//                 console.log(error);
//                 res.send(error);
//             }
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "Internal Server Error" })
//     }
// }

export async function changePassword(req: any, res: Response) {
    try {
        const { currentPassword, newPassword } = req.body;
        // old pass , new pass , confir pass

        const email = req.query.email;
        const user = await userModal.findOne({
            email: email
        });
        if (user) {
            const isMatch = await comparePassword(currentPassword, user.password);
            if (isMatch) {
                const encrypted = await hashPassword(newPassword)

                const result = await userModal.findByIdAndUpdate(user._id, {
                    password: encrypted
                })
                const token = generateAccessToken(user);
                res.send({ message: "Password updated successfully", data: { user }, token: token })
            }
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" })
    }
}

// async function superAdminValidator(email: string) {
//     const isMainAdmin = await User.findOneBy({
//         email: email
//     });

//     if ((isMainAdmin?.isSuperAdmin)) {
//         return isMainAdmin.isSuperAdmin;
//     }
// }

export async function deleteUser(req: Request, res: Response) {
    try {

        const filter = { email: req.query?.email };
        const update = { status: 'block' };
        let result = await userModal.findOneAndUpdate( filter, update  )
        res.status(200).json({ message: `User deleted successfully.`, data: result });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" })
    }
}

async function comparePassword(plaintextPassword: string | Buffer, hash: string) {
    const result = await bcrypt.compare(plaintextPassword, hash);
    return result;
}
async function hashPassword(plaintextPassword: string | Buffer) {
    const hash = await bcrypt.hash(plaintextPassword, 10);
    return hash;
}